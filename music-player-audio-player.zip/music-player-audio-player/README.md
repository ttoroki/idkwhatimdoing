# Music Player | Audio Player 🎵

A Pen created on CodePen.io. Original URL: [https://codepen.io/singhimalaya/pen/QZKqOX](https://codepen.io/singhimalaya/pen/QZKqOX).

Simple Beautiful Fully Functional Music | Audio Player.

Design inspired by: https://dribbble.com/shots/4240318-Made-with-InVision-Studio-Music-Player